import styled from "@emotion/styled";
import Typography from '@mui/material/Typography';

const Logo = styled('Typography')({

})
